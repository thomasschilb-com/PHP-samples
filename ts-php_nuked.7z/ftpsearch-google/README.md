FTP Search
===========

Uses google to search ftp sites.

With inspiration from [chrome_search_extension](https://github.com/NIT-dgp/chrome-search-extension/) by [PaliwalSparsh](https://github.com/PaliwalSparsh).